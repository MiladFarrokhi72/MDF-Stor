# MDF Store Management System

A command-line MDF sheet store management project built with Python and SQLite. This repository includes two implementations of the same application:

- **SQLite-Version** — uses Python's built-in `sqlite3` module and SQL statements.
- **Peewee-Version** — uses the Peewee ORM with SQLite as the database engine.
- **ERD** — contains the Entity Relationship Diagram for the database design.

## Database design

The system uses four main entities:

- `Customer` — customer details.
- `Sales_Expert` — sales expert details.
- `Products` / MDF sheets — product specifications and stock.
- `Sales` — sales records linked to a customer, a sales expert, and a product.

See [`ERD/MDF-Sheet-Store-ERD.png`](ERD/MDF-Sheet-Store-ERD.png) for the diagram.

## Features

Both application versions provide a numbered command-line menu for creating, displaying, searching, updating, and deleting customers, MDF sheets, sales experts, and sales. The sales workflow also updates product stock.

## Requirements

- Python 3.9 or newer
- SQLite (included with Python)
- Peewee is required only for the Peewee implementation.

## Run the SQLite version

```bash
cd SQLite-Version
python main.py
```

## Run the Peewee version

```bash
cd Peewee-Version
pip install -r requirements.txt
python main.py
```

Each version creates its own `mdf_shop.db` file in its working directory when run.

## Project structure

```text
MDF-Store/
├── SQLite-Version/
│   └── main.py
├── Peewee-Version/
│   ├── main.py
│   └── requirements.txt
├── ERD/
│   └── MDF-Sheet-Store-ERD.png
├── .gitignore
└── README.md
```
