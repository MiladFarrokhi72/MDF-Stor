import sqlite3


def connect_db():
    db = sqlite3.connect("mdf_shop.db")
    db.execute("PRAGMA foreign_keys = ON")
    return db


def create_tables():
    db = connect_db()
    cursor = db.cursor()

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS Customer (
            CustomerID INTEGER PRIMARY KEY AUTOINCREMENT,
            FirstName TEXT NOT NULL,
            LastName TEXT NOT NULL,
            Phone TEXT,
            Address TEXT
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS Sales_Expert (
            ExpertID INTEGER PRIMARY KEY AUTOINCREMENT,
            FirstName TEXT NOT NULL,
            LastName TEXT NOT NULL,
            Phone TEXT
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS Products (
            ProductID INTEGER PRIMARY KEY AUTOINCREMENT,
            Brand TEXT NOT NULL,
            Color TEXT,
            Thickness REAL,
            Length REAL,
            Width REAL,
            UnitPrice INTEGER NOT NULL,
            Stock INTEGER DEFAULT 0
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS Sales (
            SaleID INTEGER PRIMARY KEY AUTOINCREMENT,
            CustomerID INTEGER NOT NULL,
            ExpertID INTEGER NOT NULL,
            ProductID INTEGER NOT NULL,
            SaleDate TEXT,
            Quantity INTEGER NOT NULL,
            UnitPrice INTEGER NOT NULL,
            TotalPrice INTEGER NOT NULL,
            FOREIGN KEY (CustomerID) REFERENCES Customer(CustomerID),
            FOREIGN KEY (ExpertID) REFERENCES Sales_Expert(ExpertID),
            FOREIGN KEY (ProductID) REFERENCES Products(ProductID)
        )
    """)

    db.commit()
    db.close()


def get_input(message):
    return input(message).strip()


def get_int(message, minimum=None):
    while True:
        try:
            value = int(get_input(message))
            if minimum is not None and value < minimum:
                print(f"Value must be at least {minimum}.")
                continue
            return value
        except ValueError:
            print("Please enter a valid integer.")


def get_float(message, minimum=None):
    while True:
        try:
            value = float(get_input(message))
            if minimum is not None and value < minimum:
                print(f"Value must be at least {minimum}.")
                continue
            return value
        except ValueError:
            print("Please enter a valid number.")


def register_customer():
    db = connect_db()
    cursor = db.cursor()

    first = get_input("First Name: ")
    last = get_input("Last Name: ")
    phone = get_input("Phone: ")
    address = get_input("Address: ")

    cursor.execute("""
        INSERT INTO Customer (FirstName, LastName, Phone, Address)
        VALUES (?, ?, ?, ?)
    """, (first, last, phone, address))

    db.commit()
    print("Customer created successfully! Customer ID:", cursor.lastrowid)
    db.close()


def register_product():
    db = connect_db()
    cursor = db.cursor()

    brand = get_input("Brand: ")
    color = get_input("Color: ")
    thickness = get_float("Thickness: ", 0)
    length = get_float("Length: ", 0)
    width = get_float("Width: ", 0)
    price = get_int("Unit Price: ", 0)
    stock = get_int("Stock: ", 0)

    cursor.execute("""
        INSERT INTO Products
        (Brand, Color, Thickness, Length, Width, UnitPrice, Stock)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    """, (brand, color, thickness, length, width, price, stock))

    db.commit()
    print("Product created successfully! Product ID:", cursor.lastrowid)
    db.close()


def register_expert():
    db = connect_db()
    cursor = db.cursor()

    first = get_input("First Name: ")
    last = get_input("Last Name: ")
    phone = get_input("Phone: ")

    cursor.execute("""
        INSERT INTO Sales_Expert (FirstName, LastName, Phone)
        VALUES (?, ?, ?)
    """, (first, last, phone))

    db.commit()
    print("Sales expert created successfully! Expert ID:", cursor.lastrowid)
    db.close()


def show_data(table):
    allowed_tables = {"Customer", "Products", "Sales_Expert", "Sales"}
    if table not in allowed_tables:
        print("Invalid table!")
        return

    db = connect_db()
    cursor = db.cursor()
    cursor.execute(f"SELECT * FROM {table}")
    records = cursor.fetchall()

    if records:
        for record in records:
            print(record)
    else:
        print("No information found!")

    db.close()


def search_data(table, id_field):
    db = connect_db()
    cursor = db.cursor()
    user_id = get_int("Enter ID: ", 1)

    cursor.execute(
        f"SELECT * FROM {table} WHERE {id_field} = ?",
        (user_id,)
    )
    result = cursor.fetchone()

    if result:
        print("Information found:")
        print(result)
    else:
        print("Record not found!")

    db.close()


def delete_data(table, id_field):
    db = connect_db()
    cursor = db.cursor()
    user_id = get_int("Enter ID to delete: ", 1)

    cursor.execute(
        f"SELECT * FROM {table} WHERE {id_field} = ?",
        (user_id,)
    )
    result = cursor.fetchone()

    if result:
        confirm = get_input("Are you sure? (y/n): ")
        if confirm.lower() == "y":
            try:
                cursor.execute(
                    f"DELETE FROM {table} WHERE {id_field} = ?",
                    (user_id,)
                )
                db.commit()
                print("Record deleted successfully!")
            except sqlite3.IntegrityError:
                print("Cannot delete! This record is used in Sales.")
        else:
            print("Delete cancelled!")
    else:
        print("Record not found!")

    db.close()


def update_data(table, id_field, fields):
    db = connect_db()
    cursor = db.cursor()
    user_id = get_int("Enter ID to update: ", 1)

    cursor.execute(
        f"SELECT * FROM {table} WHERE {id_field} = ?",
        (user_id,)
    )
    result = cursor.fetchone()

    if not result:
        print("Record not found!")
        db.close()
        return

    print("Leave blank to keep the previous value.")
    values = []

    for index, field in enumerate(fields):
        new_value = get_input(f"Enter new {field}: ")
        values.append(result[index + 1] if new_value == "" else new_value)

    query = ", ".join(f"{field} = ?" for field in fields)

    try:
        cursor.execute(
            f"UPDATE {table} SET {query} WHERE {id_field} = ?",
            (*values, user_id)
        )
        db.commit()
        print("Information updated successfully!")
    except sqlite3.IntegrityError as error:
        print("Update failed:", error)

    db.close()


def create_sale():
    db = connect_db()
    cursor = db.cursor()

    customer_id = get_int("Customer ID: ", 1)
    expert_id = get_int("Sales Expert ID: ", 1)
    product_id = get_int("Product ID: ", 1)

    # Check that the selected records exist.
    cursor.execute("SELECT CustomerID FROM Customer WHERE CustomerID = ?", (customer_id,))
    if cursor.fetchone() is None:
        print("Customer ID not found.")
        db.close()
        return

    cursor.execute("SELECT ExpertID FROM Sales_Expert WHERE ExpertID = ?", (expert_id,))
    if cursor.fetchone() is None:
        print("Sales Expert ID not found.")
        db.close()
        return

    cursor.execute(
        "SELECT UnitPrice FROM Products WHERE ProductID = ?",
        (product_id,)
    )
    product = cursor.fetchone()
    if product is None:
        print("Product ID not found.")
        db.close()
        return

    sale_date = get_input("Sale Date (YYYY-MM-DD): ")
    quantity = get_int("Quantity: ", 1)
    unit_price = product[0]
    total_price = quantity * unit_price

    cursor.execute("""
        INSERT INTO Sales
        (CustomerID, ExpertID, ProductID, SaleDate,
         Quantity, UnitPrice, TotalPrice)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    """, (
        customer_id, expert_id, product_id, sale_date,
        quantity, unit_price, total_price
    ))

    db.commit()
    print("Sale created successfully!")
    print("Sale ID:", cursor.lastrowid)
    print("Unit Price:", unit_price)
    print("Total Price:", total_price)
    db.close()


def update_sale():
    db = connect_db()
    cursor = db.cursor()
    sale_id = get_int("Enter Sale ID to update: ", 1)

    cursor.execute("SELECT * FROM Sales WHERE SaleID = ?", (sale_id,))
    sale = cursor.fetchone()

    if sale is None:
        print("Sale not found!")
        db.close()
        return

    print("Leave blank to keep the previous value.")

    customer_text = get_input(f"Customer ID [{sale[1]}]: ")
    expert_text = get_input(f"Expert ID [{sale[2]}]: ")
    product_text = get_input(f"Product ID [{sale[3]}]: ")
    date_text = get_input(f"Sale Date [{sale[4]}]: ")
    quantity_text = get_input(f"Quantity [{sale[5]}]: ")

    try:
        customer_id = int(customer_text) if customer_text else sale[1]
        expert_id = int(expert_text) if expert_text else sale[2]
        product_id = int(product_text) if product_text else sale[3]
        sale_date = date_text if date_text else sale[4]
        quantity = int(quantity_text) if quantity_text else sale[5]

        if quantity < 1:
            raise ValueError

        for table, field, value in [
            ("Customer", "CustomerID", customer_id),
            ("Sales_Expert", "ExpertID", expert_id),
            ("Products", "ProductID", product_id)
        ]:
            cursor.execute(
                f"SELECT {field} FROM {table} WHERE {field} = ?",
                (value,)
            )
            if cursor.fetchone() is None:
                print(f"{field} {value} not found.")
                db.close()
                return

        cursor.execute(
            "SELECT UnitPrice FROM Products WHERE ProductID = ?",
            (product_id,)
        )
        unit_price = cursor.fetchone()[0]
        total_price = quantity * unit_price

        cursor.execute("""
            UPDATE Sales
            SET CustomerID = ?, ExpertID = ?, ProductID = ?,
                SaleDate = ?, Quantity = ?, UnitPrice = ?, TotalPrice = ?
            WHERE SaleID = ?
        """, (
            customer_id, expert_id, product_id, sale_date,
            quantity, unit_price, total_price, sale_id
        ))

        db.commit()
        print("Sale updated successfully!")
        print("New Total Price:", total_price)

    except ValueError:
        print("Invalid input. IDs and quantity must be valid numbers.")
    except sqlite3.IntegrityError as error:
        print("Update failed:", error)

    db.close()


def menu():
    while True:
        print("""
====================================
       MDF SHOP MANAGEMENT
====================================

1.  Create Customer
2.  Create MDF Sheet
3.  Create Sales Expert
4.  Create Sale

5.  Show Customers
6.  Show MDF Sheets
7.  Show Sales Experts
8.  Show Sales

9.  Delete Customer
10. Delete MDF Sheet
11. Delete Sales Expert
12. Delete Sale

13. Search Customer
14. Search MDF Sheet
15. Search Sales Expert
16. Search Sale

17. Update Customer
18. Update MDF Sheet
19. Update Sales Expert
20. Update Sale

0. Exit

====================================
""")

        choice = get_input("Please Select: ")

        if choice == "1":
            register_customer()
        elif choice == "2":
            register_product()
        elif choice == "3":
            register_expert()
        elif choice == "4":
            create_sale()
        elif choice == "5":
            show_data("Customer")
        elif choice == "6":
            show_data("Products")
        elif choice == "7":
            show_data("Sales_Expert")
        elif choice == "8":
            show_data("Sales")
        elif choice == "9":
            delete_data("Customer", "CustomerID")
        elif choice == "10":
            delete_data("Products", "ProductID")
        elif choice == "11":
            delete_data("Sales_Expert", "ExpertID")
        elif choice == "12":
            delete_data("Sales", "SaleID")
        elif choice == "13":
            search_data("Customer", "CustomerID")
        elif choice == "14":
            search_data("Products", "ProductID")
        elif choice == "15":
            search_data("Sales_Expert", "ExpertID")
        elif choice == "16":
            search_data("Sales", "SaleID")
        elif choice == "17":
            update_data(
                "Customer", "CustomerID",
                ["FirstName", "LastName", "Phone", "Address"]
            )
        elif choice == "18":
            update_data(
                "Products", "ProductID",
                ["Brand", "Color", "Thickness", "Length",
                 "Width", "UnitPrice", "Stock"]
            )
        elif choice == "19":
            update_data(
                "Sales_Expert", "ExpertID",
                ["FirstName", "LastName", "Phone"]
            )
        elif choice == "20":
            update_sale()
        elif choice == "0":
            print("Goodbye!")
            break
        else:
            print("Invalid choice! Try again.")


if __name__ == "__main__":
    create_tables()
    menu()
